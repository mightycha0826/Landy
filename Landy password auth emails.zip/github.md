repo: mightycha0826/Landy
branch: main

## Last sync
date: 2026-10-07T06:16:30Z

### Updated in this project
- Supabase auth email templates (Confirm signup, Magic Link) using `{{ .Token }}` codes only
- Preview page rendering both with sample values

## Screen map
| Project file | Repo files |
|---|---|
| email/confirm-signup.html | src/app.css (tokens), src/lib/state.svelte.ts (sendOtp), src/routes/login/+page.svelte, README.md (메일 템플릿, 8자리 · 10분) |
| email/magic-link.html | src/app.css, src/lib/state.svelte.ts (sendResetOtp, sendOtpToMe), src/routes/login/+page.svelte |
| Auth Emails Preview.dc.html | static/icon-192.png |
